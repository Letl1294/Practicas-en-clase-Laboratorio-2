﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;

namespace MiCalculadora
{
    public partial class FormCalculadora : Form
    {
        private object cmbOperador;

        public FormCalculadora()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            textBox1.Text = "0";
            textBox2.Text = "0";
            comboBox1.Text = " +";
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBox1.Text = "+";
            comboBox1.Text = "/";
            comboBox1.Text = "*";
            comboBox1.Text = "-";

        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            comboBox1.Text = "";
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
          
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Operar_Click(object sender, EventArgs e)
        {
             Numero primerNum;
            Numero segundoNum;
            String operador = comboBox1.Text;

    
                primerNum = new Numero(textBox1.Text);
                segundoNum = new Numero(textBox2.Text);
                Resultado.Text = Convert.ToString(Calculadora.Operar(primerNum, segundoNum, operador));
        
               //Resultado.Text = ex.Message;
        }

        private void Resultado_Click(object sender, EventArgs e)
        {

        }
    }
}