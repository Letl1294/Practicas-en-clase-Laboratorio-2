﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class DirectorTecnico : Persona
    {
        private int añosExperiencia;

        public int SetAñosExperiencia
        {
            set
            {
                this.añosExperiencia = value;  
            }
        }

        public int GetAñosExperiencia
        {
            get
            {
                return this.añosExperiencia;
            }
        }

        public DirectorTecnico(string nombre, string apellido, int edad, int dni, int añosExperiencia) : base(nombre,apellido,edad,dni)
        {
            this.añosExperiencia = añosExperiencia;
        }

        public override string Mostrar()
        {
            StringBuilder persona = new StringBuilder();
            persona.Append(base.Mostrar());
            persona.AppendLine();
            persona.Append("Años de experiencia: " + this.añosExperiencia);
            return persona.ToString();
        }

        public override bool ValidarAptitud()
        {
            if(this.GetEdad<65 && añosExperiencia>=2)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}