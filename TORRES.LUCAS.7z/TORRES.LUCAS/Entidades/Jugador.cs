﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Jugador : Persona 
    {
        private float altura;
        private float peso;
        private Posicion posicion;

        public float GetAltura
        {
            get
            {
                return altura;
            }
        }

        public float GetPeso
        {
            get
            {
                return peso;
            }
        }

        public Jugador(string nombre, string apellido, int edad, int dni, float peso, float altura, Posicion posicion) : base(nombre,apellido,edad,dni)
        {
            this.altura = altura;
            this.posicion = posicion;
        }

        public override string Mostrar()
        {
            StringBuilder jugador = new StringBuilder();
            jugador.Append(base.Mostrar());
            jugador.AppendLine();
            jugador.AppendFormat("Altura: {0:#.##}: "+altura);
            jugador.AppendLine();
            jugador.AppendFormat("Peso: ");
            return jugador.ToString();
        }

        public bool validarEstadoFisico()
        {
            float imc = (peso / (altura*altura));
            if (imc >= 18.5 && imc <= 25)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public override bool ValidarAptitud()
        {
            if(this.GetEdad<=40 && (validarEstadoFisico()))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
