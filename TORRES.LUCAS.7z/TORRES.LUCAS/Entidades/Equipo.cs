﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Equipo
    {
        private const int cantidadMaximaJugadores = 6;
        private DirectorTecnico directorTecnico;
        private List<Jugador> jugadores;
        private string Nombre;

        public DirectorTecnico DirectorTecnico
        {
            set
            {
                this.directoTecnico = value;
            }
        }

        public string GetNombre
        {
            get
            {
                return Nombre;
            }
        }

        private Equipo()
        {
            this.jugadores = new List<Jugador>();
        }

        public Equipo(string nombre) : this()
        {
            this.Nombre = nombre;
        }

        public static explicit operator string(Equipo e)
        {
            StringBuilder equipo = new StringBuilder();

            return equipo.ToString();
        }
    }
}
