﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public abstract class Persona
    {
        private string apellido;
        private int dni;
        private int edad;
        private string nombre;

        public string GetApellido
        {
            get
            {
                return apellido;
            }
        }

        public int GetDni
        {
            get
            {
                return dni;
            }
        }

        public int GetEdad
        {
            get
            {
                return edad;
            }
        }

        public string GetNombre
        {
            get
            {
                return nombre;
            }
        }

        public virtual string Mostrar()
        {
            StringBuilder persona = new StringBuilder();
            persona.Append("Nombre: "+this.nombre);
            persona.AppendLine();
            persona.Append("Apellido: "+this.apellido);
            persona.AppendLine();
            persona.Append("Edad: "+this.edad);
            persona.AppendLine();
            persona.AppendFormat("DNI: {0: ##.###.###} "+this.dni);
            persona.AppendLine();
            return persona.ToString();
        }

        public Persona(string Nombre,string Apellido,int edad, int dni)
        {
            this.apellido = Apellido;
            this.nombre = Nombre;
            this.edad = edad;
            this.dni = dni;
        }

        public abstract bool ValidarAptitud();
    }
}
