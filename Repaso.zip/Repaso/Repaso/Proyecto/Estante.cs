﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto
{
    class Estante
    {
        private int ubicacionEstante;
        private Producto[] producto;

        private Estante(int capacidad)
        {
            this.producto = new Producto[capacidad]; 
        }

        public Estante(int capacidad,int ubicacion):this(capacidad)
        {
            this.ubicacionEstante = ubicacion;
        }

        public Producto[] getProductos()
        {
            return this.producto;
        }

        public static string MostrarEstante(Estante e)
        {
            string cadena = "";

            foreach (Producto p in e.producto)
            {
                if(!Object.ReferenceEquals(p,null))
                {
                    cadena += Producto.MostrarProducto(p) + "\n";
                }
                
            }
            cadena += "Ubicacion del estante: " + e.ubicacionEstante;
            return cadena;
        }

        public static bool operator ==(Estante e, Producto p)
        {
            Boolean retorno = false;
            foreach (Producto p1 in e.producto)
            {
                if (!Object.ReferenceEquals(p1, null))
                {
                    if (p1 == p)
                    {
                        retorno = true;
                        break;
                    }
                    else
                    {
                        retorno = false;
                    }
                }
            }
            return retorno;
        }

        public static bool operator !=(Estante e, Producto p)
        {
            Boolean retorno = true;
            foreach (Producto p1 in e.producto)
            {
                if (!Object.ReferenceEquals(p1, null))
                {
                    if (p1 == p)
                    {
                        retorno = false;
                        break;
                    }
                    else
                    {
                        retorno = true;
                    }
                }
            }
            return retorno;
        }

        public static bool operator +(Estante e, Producto p)
        {
            Boolean retorno = false;
            for(int i=0;i<e.producto.Length;i++)
            {
                if (e != p && Object.ReferenceEquals(e.producto[i], null))
                {
                     e.producto[i] = p;
                     retorno = true;
                     break;
                }
                else
                {
                    retorno = false;
                }
            }
            return retorno;
        }

        public static Estante operator -(Estante e, Producto p)
        {
            if (e == p)
            {
                for (int i = 0; i < e.producto.Length; i++)
                {
                    if (Object.ReferenceEquals(e.producto[i], p))
                    {
                        e.producto[i] = null;
                        break;
                    }
                }
            }
            return e;
        }
    }
}
