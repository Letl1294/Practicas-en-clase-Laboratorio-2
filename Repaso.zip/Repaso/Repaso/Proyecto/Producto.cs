﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto
{
    class Producto
    {
        private string codigoDeBarra;
        private string marca;
        private float precio;

        //Constructor
        public Producto(string marca, string codigoDeBarras, float precio)
        {
            this.marca = marca;
            this.codigoDeBarra = codigoDeBarras;
            this.precio = precio;
        }
        public string GetMarca()
        {
            return this.marca;
        }

        public float GetPrecio()
        {
            return this.precio;
        }

        public static string MostrarProducto(Producto p)
        {
            string cadena = "";
            cadena += "La marca del producto es: " + p.marca + "\n" + "El precio es: " + p.precio + "\n" + "Codigo de barra: " + p.codigoDeBarra;
            return cadena;
        }

        public static explicit operator string(Producto p)
        {
            string codigo;
            codigo = p.codigoDeBarra;
            return codigo;
        }

        public static bool operator == (Producto pUno, Producto pDos)
        {
            if(pUno.marca == pDos.marca && pUno.codigoDeBarra == pDos.codigoDeBarra)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool operator !=(Producto pUno, Producto pDos)
        {
            if (pUno.marca == pDos.marca && pUno.codigoDeBarra == pDos.codigoDeBarra)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public static bool operator ==(Producto pUno, string Marca)
        {
            if(pUno.marca==Marca)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool operator !=(Producto pUno, string Marca)
        {
            if (pUno.marca != Marca)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
    }
}
