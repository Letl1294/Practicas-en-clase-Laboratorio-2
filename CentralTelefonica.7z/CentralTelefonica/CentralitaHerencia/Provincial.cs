﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralitaHerencia
{
    public class Provincial : Llamada
    {
        public enum Franja
        {
            Franja_1,
            Franja_2,
            Franja_3,
        };

        protected Franja franjaHoraria;

        public float CostoLlamada
        {
            get
            {
                return this.CalcularCosto();
            }
        }

        private float CalcularCosto()
        {
            float costo = 0;
            switch(this.franjaHoraria)
            {
                case Franja.Franja_1:
                    costo = (float)0.99;
                    break;
                case Franja.Franja_2:
                    costo = (float)1.25;
                    break;
                case Franja.Franja_3:
                    costo = (float)0.66;
                    break;
            }
            return costo * base.duracion;
        }

        public override string Mostrar()
        {
            StringBuilder datos = new StringBuilder();
            datos.AppendLine(base.Mostrar());
            datos.AppendFormat("\nCosto llamada: {0}",this.CostoLlamada);
            datos.AppendFormat("\nFranja Horaria:{0}",this.franjaHoraria);
            return datos.ToString();
        }

        public Provincial(Franja miFranja, Llamada llamada) : this(llamada.NroOrigen,miFranja,llamada.Duracion,llamada.NroDestino)
        {
        }

        public Provincial(string origen, Franja miFranja, float duracion, string destino) :base(duracion,destino,origen)
        {
            this.franjaHoraria = miFranja;
        }
    }
}
