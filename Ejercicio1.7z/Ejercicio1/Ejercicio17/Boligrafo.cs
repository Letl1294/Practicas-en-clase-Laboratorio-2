﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio17
{
    class Boligrafo
    {
        private short cantidadTintaMaxima = 100;
        private ConsoleColor Color;
        private short Tinta;
    

    public Boligrafo(ConsoleColor color, short tinta)
    {
       this.Color = color;
       this.Tinta = tinta;
    }

    public ConsoleColor GetColor()
    {
        return this.Color;
    }

    public short GetTinta()
    {
        return this.Tinta;
    }
    private Boolean SetTinta(short tinta)
    {
        if(tinta>=0 && tinta<=100)
        {
            this.Tinta = tinta;
            return true;
        }
        else
        {
            return false;
        }
    }
    private void Recargar()
    {
         this.Tinta = 100;
    }
    public void Pintar(short nivel, out string pintar)
    {
        pintar = "";
        //ConsoleColor color = this.Color;

        if(nivel > 0)
        {
            for(int i = 0; this.Tinta > 0 && i < nivel; i++)
            {
               this.Tinta = -1;
               pintar += "*";
            }
            Console.WriteLine("Usted esta pintando en {0}", this.GetColor());
            Console.WriteLine("PINTANDO..");
            Console.WriteLine(pintar);
            Console.WriteLine("Nivel de tinta despues de pintar {0}", this.Tinta);
            Console.WriteLine("-------------");
            }
        else
        {
            Console.Write("No se pinta");
        }
    }

    }
}
