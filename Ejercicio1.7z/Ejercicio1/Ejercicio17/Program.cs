﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio17
{
    class Program
    {
        static void Main(string[] args)
        {
            Boligrafo boli1 = new Boligrafo(ConsoleColor.Blue, 100);
            Boligrafo boli2 = new Boligrafo(ConsoleColor.Red, 50);
            String pintar;

            boli1.Pintar(10, out pintar);
            boli2.Pintar(47, out pintar);

            Console.ReadKey();
        }
    }
}
