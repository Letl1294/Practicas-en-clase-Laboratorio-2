﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio6
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese un año de incio: ");
            int añoIni = int.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese un año de fin: ");
            int añoFin = int.Parse(Console.ReadLine());
            for(int i=añoIni;i<añoFin;i++)
            {
                if((i%4==0 && i%100!=0) || (i%100==0 && i%400==0))
                {
               
                     Console.WriteLine("Ano bisiesto: " + i);
                }
            }
            Console.ReadKey();
        }
    }
}
