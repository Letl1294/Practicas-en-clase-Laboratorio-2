﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio8
{
    class Program
    {
        static void Main(string[] args)
        {
            int ValorHora;
            string nombre;
            int años;
            int horasTrabajadas;
            Console.WriteLine("Ingrese el valor hora: ");
            //ValorHora = Parse.int();
        }
    }
}
