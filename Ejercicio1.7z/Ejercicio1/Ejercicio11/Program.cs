﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace Ejercicio11
{
    class Program
    {   
        static void Main(string[] args)
        {
            int numero;
            Console.WriteLine("Ingrese un numero entre -100 y 100");
            numero = int.Parse(Console.ReadLine());

            if(Validacion.Validar(numero, -100, 100)==true)
            {
                Console.Write("el numero es: "+numero);
            }
            else
            {
                Console.Write("El numero esta fuera del rango");
            }
            Console.ReadKey();
        }
    }
}