﻿    using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio20
{
    class Pesos
    {
        private Double cantidad;
        static float cotizRespectoDolar;

        static Pesos()
        {
            Pesos.cotizRespectoDolar = 38.33f;
        }

        public double getCantidad()
        {
            return this.cantidad;
        }

        public static float getCotizacion()
        {
            return Pesos.cotizRespectoDolar;
        }

        public Pesos(double cantidad)
        {
            this.cantidad = cantidad;
        }

        public Pesos(double Cantidad, float cotizacion) : this(Cantidad)
        {
            cotizRespectoDolar = cotizacion;
        }

        public static explicit operator Dolar(Pesos p)
        {
            return new Dolar(p.getCantidad() / cotizRespectoDolar);
        }

        public static explicit operator Euro(Pesos p)
        {
            return new Euro(p.getCantidad() / cotizRespectoDolar);
        }

        public static implicit operator Pesos(double cantidad)
        {
            return new Pesos(cantidad);
        }

        public static bool operator ==(Pesos p, Dolar d)
        {
            if(p.getCantidad()==(d.getCantidad() / cotizRespectoDolar))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool operator ==(Pesos p, Euro e)
        {
            if (p.getCantidad() == (e.getCantidad() * Euro.getCotizacion()) / cotizRespectoDolar)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool operator ==(Pesos p1, Pesos p2)
        {
            if (p1.getCantidad() == p2.getCantidad())
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool operator != (Pesos p, Dolar d)
        {
            return !(p == d);
        }

        public static bool operator !=(Pesos p, Euro e)
        {
            return !(p == e);
        }

        public static bool operator !=(Pesos p1, Pesos p2)
        {
            return !(p1 == p2);
        }

        public static Pesos operator +(Pesos p, Dolar d)
        {
            //return New Pesos(p.cantidad + Dolar.(d);
        }

    }
}
