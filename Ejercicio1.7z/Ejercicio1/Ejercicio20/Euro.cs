﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio20
{
    class Euro
    {
        private double cantidad;
        static float cotizRespectoDolar;

        static Euro()
        {
            Euro.cotizRespectoDolar = 1.16f;
        }

        public Euro(double cantidad)
        {
            this.cantidad = cantidad;
        }

        public Euro(float cotizRespectoDolar, double cantidad) : this(cantidad)
        {
            Euro.cotizRespectoDolar = cotizRespectoDolar;
        }
        
        public double getCantidad()
        {
            return this.cantidad;
        }

        public static float getCotizacion()
        {
            return Euro.cotizRespectoDolar;
        }

        public static explicit operator Dolar(Euro e)
        {
            return new Dolar(e.getCantidad() * Euro.getCotizacion());
        }

        public static explicit operator Pesos(Euro e)
        {
            return new Pesos((e.getCantidad() * Euro.getCotizacion()) * Pesos.getCotizacion());
        }

        public static implicit operator Euro(double e)
        {
            return new Euro(e);
        }
    }
}
