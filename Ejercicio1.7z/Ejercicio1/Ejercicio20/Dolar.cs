﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio20
{
    class Dolar
    {
        private double Cantidad;
        static float cotizRespectoDolar;

        static Dolar()
        {
            Dolar.cotizRespectoDolar = 1;
        }

        public Dolar(double Cantidad)
        {
            this.Cantidad = Cantidad;
        }

        public Dolar(double Cantidad, float cotizacion):this(Cantidad)
        {
            Dolar.cotizRespectoDolar = cotizacion;
        }

        public double getCantidad()
        {
            return this.Cantidad;
        }

        public static float getCotizacion()
        {
            return Dolar.cotizRespectoDolar;
        }

        public static explicit operator Euro(Dolar d)
        {
            return new Euro(d.getCantidad() / Euro.getCotizacion());
        }

        public static explicit operator Pesos(Dolar d)
        {
            return new Pesos(d.getCantidad() * Pesos.getCotizacion());
        }

        public static implicit operator Dolar(double d)
        {
            return new Dolar(d);
        }
    }
}
