﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio7
{
    class Program
    {
        static void Main(string[] args)
        {
            DateTime fechaNac;
            DateTime hoy = DateTime.Now;
            TimeSpan diferencia;
            Console.WriteLine("Ingrese la fecha de nacimiento: dd/mm/aaaa");
            fechaNac = DateTime.Parse(Console.ReadLine());
            Console.WriteLine("Fecha de nacimiento: "+ fechaNac);
            Console.WriteLine("Fecha de hoy: " + hoy);
            int diasBis=0;
            for(int i=fechaNac.Year;i<hoy.Year;i++)
            {
                if ((i % 4 == 0 && i % 100 != 0) || (i % 100 == 0 && i % 400 == 0))
                {
                    diasBis++;
                }
            }
            diferencia = hoy - fechaNac;
            int diasVid = diferencia.Days;
            diasVid+= diasBis;
            Console.Write("dias: "+diasVid);
            Console.ReadKey();
        }
    }
}
