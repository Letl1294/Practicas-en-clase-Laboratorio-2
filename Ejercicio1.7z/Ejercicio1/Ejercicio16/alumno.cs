﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio16
{
    class alumno
    {
        private byte nota1;
        private byte nota2;
        private double notaFinal;
        String apellido;
        int legajo;
        String nombre;

        public static void datos(alumno alum)
        {
            Console.WriteLine("Ingrese el nombre");
            alum.nombre = (String)(Console.ReadLine());
            Console.WriteLine("Ingrese el Apellido");
            alum.apellido = (String)(Console.ReadLine());
            Console.WriteLine("Ingrese el legajo");
            alum.legajo = int.Parse(Console.ReadLine());
        }

        public void CalcularFinal()
        {
            if(nota1>= 4 && nota2>=4)
            {
               Random random = new Random();
               notaFinal = random.Next(1,10);
            }
            else
            {
                notaFinal = -1;
            }
        }
        public void Estudiar(byte NotaUno, byte NotaDos)
        {
            this.nota1 = NotaUno;
            this.nota2 = NotaDos;
        }
        public void Mostrar()
        {
            Console.Write("Nombre: "+this.nombre);
            Console.Write("Apellido: " + this.apellido);
            Console.Write("legajo: " + this.legajo);
            if(this.notaFinal!=-1)
            {
                Console.Write("Nota final: " + this.notaFinal);
            }
            else
            {
                Console.WriteLine("Alumno Desaprobado");
            }   
        }
    }
}
