﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio16
{
    class Program
    {
        static void Main(string[] args)
        {
            alumno alum1 = new alumno();
            alumno alum2 = new alumno();
            alumno alum3 = new alumno();

            alumno.datos(alum1);
            alumno.datos(alum2);
            alumno.datos(alum3);

            alum1.Estudiar(5,5);
            alum2.Estudiar(9,3);
            alum3.Estudiar(1,2);

            alum1.CalcularFinal();
            alum2.CalcularFinal();
            alum3.CalcularFinal();

            alum1.Mostrar();
            alum2.Mostrar();
            alum3.Mostrar();

            Console.ReadKey();
        }
    }
}
