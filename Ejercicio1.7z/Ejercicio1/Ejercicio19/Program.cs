﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio19
{
    class Program
    {
        static void Main(string[] args)
        {
            Sumador sumaUno = new Sumador();
            Sumador sumaDos = new Sumador();
            long sumarUno,sumarDos;
            string sumasUno,sumasDos;
            sumarUno = sumaUno.Sumar(5,3);
            sumasUno = sumaUno.Sumar("5","3");
            sumarDos = sumaDos.Sumar(8, 1);
            sumasDos = sumaDos.Sumar("8", "1");
            long sumas = sumaUno + sumaDos;
            Boolean igual = sumaUno | sumaDos;
            Console.Write(sumasUno);
            Console.Write(sumarUno);
            Console.Write(sumasDos);
            Console.Write(sumarDos);
            Console.Write("\n"+sumas);
            Console.Write("\n"+igual);
            Console.ReadKey();
        }
    }
}
