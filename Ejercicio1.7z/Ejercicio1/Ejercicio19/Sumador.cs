﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio19
{
    class Sumador
    {
        private int cantidadSumas;

        public Sumador(int sum)
        {
            this.cantidadSumas = sum;
        }

        public Sumador():this(0)//De esta manera le paso un 0 al primer contrustor(lo reutilizamos).
        {

        }

        public long Sumar(long uno, long dos)
        {
            long suma = uno + dos;
            this.cantidadSumas++;
            return suma;
        }

        public string Sumar(string uno,string dos)
        {
            string suma = "\n" + "Suma: " + uno + " + " + dos + " = " ;
            this.cantidadSumas++;
            return suma;
        }

        public static explicit operator int(Sumador s)
        {
            int cantidadSumas = s.cantidadSumas;
            return cantidadSumas;
        }

        public static long operator +(Sumador s1, Sumador s2)
        {
            long cantidadSumas;
            cantidadSumas = s1.cantidadSumas + s2.cantidadSumas;
            return cantidadSumas;
        }

        public static bool operator |(Sumador s1, Sumador s2)
        {
            if(s1.cantidadSumas==s2.cantidadSumas)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
