﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio13
{
    class Program
    {
        static void Main(string[] args)
        {
            double num=0;
            string num1;
            Console.WriteLine("Ingrese un numero:");
            num = double.Parse(Console.ReadLine());
            num1 = Conversor.DecimalBinario(num);
            num = Conversor.BinaroDecimal(num1);
            Console.WriteLine("binario: " + num1);
            Console.WriteLine("Decimal: "+num);
            Console.ReadKey();
        }
    }
}
