﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio13
{
    class Conversor
    {
        public static string DecimalBinario(double num)
        {
            string bin="";
            while (num > 0)
            {
                if(num%2==0)
                {
                    bin = "0"+ bin;
                }
                else
                {
                    bin = "1"+ bin;
                }
                num = (int)(num / 2);
            }
            Console.WriteLine("Listo");
            return bin;
        }
        public static double BinaroDecimal(string num)
        {
            char[] array = num.ToCharArray();
            // Invertido pues los valores van incrementandose de derecha a izquierda: 16-8-4-2-1
            Array.Reverse(array);
            double sum = 0;

            for (int i = 0; i < array.Length; i++)
            {
                if (array[i] == '1')
                {
                    // Usamos la potencia de 2, según la posición
                    sum += (int)Math.Pow(2, i);
                }
            }
            return sum;
        }
    }
}