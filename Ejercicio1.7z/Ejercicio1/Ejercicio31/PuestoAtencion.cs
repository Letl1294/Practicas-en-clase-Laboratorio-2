﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Ejercicio31
{
    class PuestoAtencion
    {
        static private int numeroActual;

        static PuestoAtencion()
        {
            PuestoAtencion.numeroActual = 0;
        }

        public bool Atender(Cliente cli)
        {
            Thread.Sleep(1000);
            return true;
        }

        static int NumeroActual
        {
            get
            {
                numeroActual++;
                return numeroActual;
            }
        }

    }
}
