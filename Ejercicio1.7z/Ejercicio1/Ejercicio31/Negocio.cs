﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio31
{
    class Negocio
    {
        private PuestoAtencion Caja;
        private Cliente clientes;
        private string nombre;

        public Cliente setCliente
        {
            set
            {
                clientes = value;
            }
        }

        public Cliente getCliente
        {
            get
            {
                return clientes;   
            }
        }

        private void negocio()
        {

        }

        public  void negocio(string nombre)
        {

        }
    }
}
