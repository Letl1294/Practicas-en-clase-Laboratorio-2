﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio31
{
    class Cliente
    {
        private String nombre;
        private int numero;

        public string setNombre
        {
            set
            {
                this.nombre = value;
            }
        }

        public string getNombre
        {
            get
            {
                return this.nombre;
            }
        }

        public int getNumero
        {
            get
            {
                return this.numero;
            }
        }

        public static void cliente(int num)
        {
            Cliente c = new Cliente();
            int numero = c.getNumero;
            numero = num;
        }

        public static void cliente(int numero, string nombre)
        {
            
        }

        public static bool operator ==(Cliente cliente1, Cliente cliente2)
        {
            if (cliente1 == cliente2)
            {
                return true;
            }
            else

            return false;
        }

        public static bool operator !=(Cliente cliente1, Cliente cliente2)
        {
            if (cliente1 == cliente2)
            {
                return true;
            }
            else
                return false;
        }
    }
}