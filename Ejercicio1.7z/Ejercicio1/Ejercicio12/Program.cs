﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio12
{
    class Program
    {
        static void Main(string[] args)
        {
            char opcion;
            int numero;

            do
            {
                Console.WriteLine("Ingrese un numero: ");
                numero = int.Parse(Console.ReadLine());
                Console.WriteLine("Desea ingresar otro numero: s/n");
                opcion = char.Parse(Console.ReadLine());
            }
            while (ValidarRespuesta.ValidaS_N(opcion) == true);
            Console.ReadKey();
        }

    }
}
