using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComiqueriaLogic
{
  sealed class Venta
  {
    static int porcentajeIva;
    private DateTime fecha;
    private double precioFinal;
    private Producto producto;

    private DateTime Fecha
    {
      get
      {
        return fecha;
      }
    }

    static Venta()
    {
      porcentajeIva = 21;
    }

    private Venta(Producto producto, int cantidad)
    {
      this.producto = producto;
      Vender(cantidad);
    }

    private void Vender(int cantidad)
    {
      this.producto.Stock -= cantidad;
      this.fecha = DateTime.Now;
      this.precioFinal = CalcularPrecioFinal(producto.Precio,cantidad);
    }

    public static double CalcularPrecioFinal(double precioUnidad,int cantidad)
    {
      return (precioUnidad* cantidad)*porcentajeIva;
    }

    public string ObtenerDescripcionBreve()
    {
      StringBuilder datos = new StringBuilder();
      datos.AppendFormat("\nFecha: {0}",this.Fecha," - Descripcion: {0}",producto.Descripcion,
      " - Precio Final: {0}",this.precioFinal);
      return datos.ToString();
    }

  }
}
