using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComiqueriaLogic
{
  public class Comiqueria
  {
    List<Producto> productos;
    List<Venta> ventas;

    public Comiqueria()
    {
      productos = new List<Producto>();
      ventas = new List<Venta>();
    }

    public Producto this[Guid codigo]
    {
      get
      {
        foreach (Producto p in productos)
        {
          if ((Guid)(p) == codigo)
          {
            return p;
          }
        }
        return null;
      }
    }

    public static bool operator ==(Comiqueria comiqueria, Producto producto)
    {
      foreach(Producto p in comiqueria.productos)
      {
        if (p.Descripcion == producto.Descripcion)
        {
          return true;
        }
      }
      return false;
    }

    public static bool operator !=(Comiqueria comiqueria, Producto producto)
    {
      return !(comiqueria==producto);
    }

    public static Comiqueria operator +(Comiqueria comiqueria, Producto producto)
    {
      if(comiqueria != producto)
      {
        comiqueria.productos.Add(producto);
      }
      return comiqueria;  
    }

    public void Vender(Producto producto,int cantidad)
    {
      ventas = new List<Venta>(cantidad);
      productos.Add(producto);
    }
  
  }
}
