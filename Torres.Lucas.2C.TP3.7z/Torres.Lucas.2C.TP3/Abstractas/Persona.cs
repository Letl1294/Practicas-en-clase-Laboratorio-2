﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Abstractas
{
    class Persona
    {
        private string apellido;
        private int dni;
        private ENacionalidad nacionalidad;
        private string nombre;

        public string Apellido
        {
            get
            {
                return this.apellido;
            }
            set
            {
                this.apellido = value;
            }
        }

        public int DNI
        {
            get
            {
                return this.dni;
            }
            set
            {
                this.dni = value;
            }
        }

        public ENacionalidad Nacionalidad
        {
            get
            {
                return this.nacionalidad;
            }
            set
            {
                this.nacionalidad = value;
            }
        }

        public string Nombre
        {
            get
            {
                return this.nombre;
            }
            set
            {
                this.nombre = value;
            }
        }

        public string StringToDNI
        {
            set
            {
                //this.
            }
        }

        public Persona()
        {
            
        }

        public Persona(String nombre, string apellido,int dni, ENacionalidad nacionalidad)
        { }

        public Persona(String nombre, string apellido,string dni, ENacionalidad nacionalidad)
        { }

        public Persona(String nombre, string apellido, string dni, ENacionalidad nacionalidad)
        { }

        public string ToString()
        {
            return "";
        }

        public int ValidarDni(Enacionalidad nacionalidad, int dato)
        {
            return 1;
        }

        public int ValidarDni(Enacionalidad nacionalidad, string dato)
        {
            return 1;
        }

        public string ValidarNombreApellido(string dato)
        {
            return "";
        }

        enum Enacionalidad
        {
            Argentino,
            Extranjero,
        };
    }
}
