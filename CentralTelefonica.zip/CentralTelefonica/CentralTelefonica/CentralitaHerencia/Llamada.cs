﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralitaHerencia
{
    public abstract class Llamada
    {
        protected float duracion;
        protected string nroDestino;
        protected string nroOrigen;

        public enum TipoLlamada
        {
            Local,
            Provincial,
            Todas,
        };

        public float Duracion
        {
            get
            {
                return duracion;
            }
        }

        public string NroDestino
        {
            get
            {
                return nroDestino;
            }
        }

        public string NroOrigen
        {
            get
            {
                return nroOrigen;
            }
        }

        public Llamada(float duracion, string nroDestino, string nroOrigen)
        {
            this.duracion = duracion;
            this.nroDestino = NroDestino;
            this.nroOrigen = nroOrigen;
        }

        public virtual string Mostrar()
        {
            StringBuilder datos = new StringBuilder();
            datos.AppendFormat("Duracion: {0}",this.Duracion);
            datos.AppendFormat("\nNumero de Destino: {0}",this.NroDestino);
            datos.AppendFormat("\nNumero de origen: {0}",this.NroOrigen);
            return datos.ToString(); 
        }

        public static int OrdenarPorDuracion(Llamada llamada1, Llamada llamada2)
        {
            int orden = 0;
            if(llamada1.duracion>llamada2.duracion)
            {
                orden = 1;
            }
            if(llamada2.duracion>llamada1.duracion)
            {
                orden = -1;
            }
            return orden;
        }
    }
}
